package com.pack.webservice;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			CalculatorServiceStub stub=new CalculatorServiceStub();
			CalculatorServiceStub.Addition params=new CalculatorServiceStub.Addition();
			params.setA(40);
			params.setB(30);
			CalculatorServiceStub.Subtraction params1=new CalculatorServiceStub.Subtraction();
			params1.setA(40);
			params1.setB(30);
			CalculatorServiceStub.Multiplication params2=new CalculatorServiceStub.Multiplication();
			params2.setA(40);
			params2.setB(30);
			CalculatorServiceStub.Division params3=new CalculatorServiceStub.Division();
			params3.setA(40);
			params3.setB(30);
			
			CalculatorServiceStub.AdditionResponse response;
			CalculatorServiceStub.SubtractionResponse response1;
			CalculatorServiceStub.MultiplicationResponse response2;
			CalculatorServiceStub.DivisionResponse response3;

			
			try {
				response = stub.addition(params);
				response1 = stub.subtraction(params1);
				response2 = stub.multiplication(params2);
				response3 = stub.division(params3);

				int result=response.get_return();
				System.out.println("Result is"+ result);
				int result1=response1.get_return();
				System.out.println("Result is"+ result1);
				int result2=response2.get_return();
				System.out.println("Result is"+ result2);
				int result3=response3.get_return();
				System.out.println("Result is"+ result3);
				
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
