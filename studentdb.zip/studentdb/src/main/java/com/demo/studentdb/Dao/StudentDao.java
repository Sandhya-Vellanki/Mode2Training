package com.demo.studentdb.Dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.demo.studentdb.entity.Student;

@Repository
public interface StudentDao extends CrudRepository<Student, Integer>{

	//Optional<Student> findById(Student student);

}
