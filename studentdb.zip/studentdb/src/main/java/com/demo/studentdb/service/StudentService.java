package com.demo.studentdb.service;

import java.util.Optional;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.studentdb.Dao.StudentDao;
import com.demo.studentdb.dto.StudentDto;
import com.demo.studentdb.dto.StudentGetDto;
import com.demo.studentdb.entity.Student;
import com.demo.studentdb.exception.StudentNotFoundException;

@Service
public class StudentService {

	@Autowired
	StudentDao studentDao;
	
	ModelMapper mapper = new ModelMapper();
	
	public Student getStudentDetails(Integer studentId) {
		Optional<Student> student = studentDao.findById(studentId);
		if(student.isPresent()) {
			return student.get();
		}else{
			throw new NullPointerException();
		}
	}
		/*StudentGetDto studentGetDto = mapper.map(student, StudentGetDto.class);
		return studentGetDto;*/
	

	public void addStudent(StudentDto studentDto) {
		Student student = mapper.map(studentDto, Student.class);
		studentDao.save(student);
	}
	/*public Optional<Student> getStudentById(StudentDto studentDto) {
		Student student = mapper.map(studentDto, Student.class);
		return studentDao.findById(student);
	}*/
	/*public StudentGetDto getStudentDetail(Integer studentId) {
		Student student = studentDao.findById(studentId).orElse(null);
	if(student == null) {
		throw new StudentNotFoundException("id-" + studentId);
	}
	StudentGetDto studentGetDto = mapper.map(student, StudentGetDto.class);
	return studentGetDto;
}*/


	


}
