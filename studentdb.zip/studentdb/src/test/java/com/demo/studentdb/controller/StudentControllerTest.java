package com.demo.studentdb.controller;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import com.demo.studentdb.entity.Student;
import com.demo.studentdb.service.StudentService;
import junit.framework.Assert;

@RunWith(MockitoJUnitRunner.Silent.class)
public class StudentControllerTest {
	
	
@InjectMocks
StudentController studentcontroller;


@Mock
StudentService studentService;

@Test
public void testGetStudentDetails(){
	List<Student> students = new ArrayList<>();
	Student student= new Student();
	student.setStudentId(1);
	student.setName("fname1");
	students.add(student);
	//Optional<Student> students = Optional.of(student);
	Mockito.when(studentService.getStudentDetails(1)).thenReturn(student);
	Student resp = studentcontroller.getStudentDetails(1);
	
	Assert.assertNotNull(resp);
	Assert.assertEquals(resp.getName(), "fname1");
}





}
