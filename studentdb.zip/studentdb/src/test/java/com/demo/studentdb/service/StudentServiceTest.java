package com.demo.studentdb.service;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.demo.studentdb.Dao.StudentDao;
import com.demo.studentdb.entity.Student;
import junit.framework.Assert;

@RunWith(MockitoJUnitRunner.class)
public class StudentServiceTest {
	@Mock
	StudentDao studentDao;
	
	@InjectMocks
	StudentService studentService;
	
	@Test
	public void testgetStudentDetails(){
		Student student = new Student();
		student.setStudentId(1);
		student.setName("fname1");
		Optional<Student> students = Optional.of(student);
		
		Mockito.when(studentDao.findById(1)).thenReturn(students);
		Student resStudent = studentService.getStudentDetails(1);
		Assert.assertNotNull(resStudent);
		Assert.assertEquals(resStudent.getName(), "fname1");
	}
	
	
	@Test
	public void testgetStudentDetailsForAll(){
		Student student = new Student();
		student.setStudentId(1);
		student.setName("fname1");
		Optional<Student> students = Optional.of(student);
		
		Mockito.when(studentDao.findById(Mockito.anyInt())).thenReturn(students);
		Student resStudent = studentService.getStudentDetails(1);
		Assert.assertNotNull(resStudent);
		Assert.assertEquals(resStudent.getName(), "fname1");
	}
	
	@Test(expected=NullPointerException.class)
	public void testgetStudentDetailsForExc(){
		Student student = new Student();
		student.setStudentId(1);
		student.setName("fname1");
		Optional<Student> students = Optional.of(student);
		
		Mockito.when(studentDao.findById(1)).thenReturn(students);
		Student resStudent = studentService.getStudentDetails(2);
		/*Assert.assertNotNull(resStudent);
		Assert.assertEquals(resStudent.getName(), "fname1");
	*/}
	
	
	
	
	}
	
	


